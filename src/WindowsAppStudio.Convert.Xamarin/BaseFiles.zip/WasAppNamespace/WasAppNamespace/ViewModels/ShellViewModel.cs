﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WasAppNamespace.ViewModels;

namespace WasAppNamespace.AppStudio.ViewModels
{
    public class ShellViewModel : PageViewModelBase
    {
        public ShellViewModel()
        {
            
        }
    }
}
