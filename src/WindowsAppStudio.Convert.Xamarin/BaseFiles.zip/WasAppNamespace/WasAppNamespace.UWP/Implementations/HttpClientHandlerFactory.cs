﻿using System.Net.Http;
using Acquaint.Abstractions;

namespace WasAppNamespace.UWP
{
    public class HttpClientHandlerFactory : IHttpClientHandlerFactory
    {
        public HttpClientHandler GetHttpClientHandler()
        {
            return null;
        }
    }
}
